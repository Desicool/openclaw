/**
 * Interactive handler for the weekly-report card buttons (v9.4, 2026-05-29).
 *
 * Confirm path doc-fetch / doc-update were rewritten for the new `feishu` CLI
 * (`@richord/lark-cli` / `@fanfanv5/feishu-cli`), which uses positional `doc fetch <id>` and
 * `doc update --token <id> --mode overwrite --file <path>` — no `+`, no `--as user`. Routed
 * through `larkCli*` settings (the bot-strict `lark-cli` rejects user-identity doc ops).
 * Card sender stays on `larkOfficialCli*` (bot-mode `im +messages-send` works).
 */

import { randomBytes } from "node:crypto";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import type { PluginRuntime } from "openclaw/plugin-sdk/core";
import { SUPPLEMENT_INPUT_NAME, parseEnvelopeAction } from "./card.js";
import { spliceWeeklySection } from "./doc-splicer.js";
import { renderReport } from "./report-renderer.js";
import type { WeeklyReportPluginSettings } from "./settings.js";
import { validateCardActionTrust } from "./tools.js";
import { WEEKLY_REPORT_STEPS, isWeeklyReportFlowState } from "./types.js";

export type RunCommandFn = PluginRuntime["system"]["runCommandWithTimeout"];

export type InteractiveRespond = {
  reply: (args: { text: string }) => Promise<void>;
  followUp?: (args: { text: string }) => Promise<void>;
  editMessage?: (args: { blocks?: unknown[]; toast?: unknown }) => Promise<void>;
};

export type WeeklyReportInteractiveCtx = {
  channel: string;
  accountId?: string;
  senderId?: string;
  conversationId?: string;
  messageId?: string;
  namespace: string;
  payload: string;
  action: string;
  rawEvent: unknown;
  respond: InteractiveRespond;
};

export type WeeklyReportInteractiveResult = {
  handled: boolean;
  toast?: { type: "info" | "success" | "error" | "warning"; content: string };
};

export type CreateInteractiveHandlerDeps = {
  taskFlow: Parameters<typeof validateCardActionTrust>[0]["taskFlow"];
  controllerId: string;
  settings: WeeklyReportPluginSettings;
  runCommand: RunCommandFn;
  /** Optional. When provided, the supplement path spawns a real agent turn to re-draft. */
  subagentRun?: SubagentRunFn;
};

function safeParseEvent(raw: unknown): {
  value?: Record<string, unknown>;
  formValue?: Record<string, unknown>;
} {
  let event: Record<string, unknown> | null = null;
  if (typeof raw === "string") {
    try {
      event = JSON.parse(raw) as Record<string, unknown> | null;
    } catch {
      return {};
    }
  } else if (raw && typeof raw === "object" && !Array.isArray(raw)) {
    event = raw as Record<string, unknown>;
  }
  if (!event) return {};
  const action = event.action as Record<string, unknown> | undefined;
  const value =
    action && typeof action.value === "object" && action.value !== null && !Array.isArray(action.value)
      ? (action.value as Record<string, unknown>)
      : undefined;
  const formCandidates = [
    action?.form_value,
    action?.input_value,
    event.form_value,
    event.input_value,
  ];
  let formValue: Record<string, unknown> | undefined;
  for (const cand of formCandidates) {
    if (cand && typeof cand === "object" && !Array.isArray(cand)) {
      formValue = cand as Record<string, unknown>;
      break;
    }
  }
  return value ? { value, ...(formValue ? { formValue } : {}) } : {};
}

function readSupplementText(formValue: Record<string, unknown> | undefined): string | undefined {
  if (!formValue) return undefined;
  const raw = formValue[SUPPLEMENT_INPUT_NAME];
  if (typeof raw !== "string") return undefined;
  const trimmed = raw.trim();
  return trimmed.length === 0 ? undefined : trimmed;
}

function summarizeExecFailure(result: { stdout: string; stderr: string; code: number | null }): string {
  const trailer = result.stderr.trim() || result.stdout.trim() || `code=${result.code}`;
  return trailer.length > 240 ? `${trailer.slice(0, 239)}…` : trailer;
}

// The new `feishu` CLI mixes log lines and the JSON result on stdout. The JSON we want is the
// last top-level `{...}` block. Extract by scanning for the final balanced object.
function extractTrailingJsonObject(stdout: string): string | null {
  const trimmed = stdout.trimEnd();
  const end = trimmed.lastIndexOf("}");
  if (end < 0) return null;
  let depth = 0;
  let inStr = false;
  let escape = false;
  for (let i = end; i >= 0; i -= 1) {
    const ch = trimmed[i];
    if (escape) {
      escape = false;
      continue;
    }
    if (ch === "\\") {
      escape = true;
      continue;
    }
    if (ch === '"') {
      inStr = !inStr;
      continue;
    }
    if (inStr) continue;
    if (ch === "}") depth += 1;
    else if (ch === "{") {
      depth -= 1;
      if (depth === 0) return trimmed.slice(i, end + 1);
    }
  }
  return null;
}

async function fetchDocMarkdown(params: {
  runCommand: RunCommandFn;
  binPath: string;
  accountId: string;
  docToken: string;
  timeoutMs: number;
}): Promise<{ ok: true; markdown: string } | { ok: false; error: string }> {
  const argv = [params.binPath, "-a", params.accountId, "doc", "fetch", params.docToken];
  let result;
  try {
    result = await params.runCommand(argv, { timeoutMs: params.timeoutMs });
  } catch (err) {
    return { ok: false, error: `feishu doc fetch spawn failed: ${(err as Error).message}` };
  }
  if (result.code !== 0) {
    return { ok: false, error: `feishu doc fetch exit ${result.code} — ${summarizeExecFailure(result)}` };
  }
  const jsonText = extractTrailingJsonObject(result.stdout);
  if (!jsonText) {
    return {
      ok: false,
      error: `feishu doc fetch: no JSON object in stdout — ${result.stdout.slice(-240)}`,
    };
  }
  let parsed: unknown;
  try {
    parsed = JSON.parse(jsonText);
  } catch {
    return { ok: false, error: `feishu doc fetch: unparseable JSON — ${jsonText.slice(0, 240)}` };
  }
  if (!parsed || typeof parsed !== "object") {
    return { ok: false, error: "feishu doc fetch: response missing object" };
  }
  const obj = parsed as Record<string, unknown>;
  if (typeof obj.content === "string") return { ok: true, markdown: obj.content };
  if (typeof obj.markdown === "string") return { ok: true, markdown: obj.markdown };
  return {
    ok: false,
    error: `feishu doc fetch: no content field in response — ${JSON.stringify(obj).slice(0, 200)}`,
  };
}

async function overwriteDocMarkdown(params: {
  runCommand: RunCommandFn;
  binPath: string;
  accountId: string;
  docToken: string;
  markdown: string;
  timeoutMs: number;
}): Promise<{ ok: true } | { ok: false; error: string }> {
  // The CLI requires `--file <path>`; there's no stdin path. Write the markdown to a tempfile
  // (random dir, scoped to this process, cleaned up after the call).
  let dir: string;
  try {
    dir = await mkdtemp(join(tmpdir(), `wr-${randomBytes(6).toString("hex")}-`));
  } catch (err) {
    return { ok: false, error: `temp dir create failed: ${(err as Error).message}` };
  }
  const filePath = join(dir, "weekly-report.md");
  try {
    await writeFile(filePath, params.markdown, "utf8");
  } catch (err) {
    await rm(dir, { recursive: true, force: true }).catch(() => {});
    return { ok: false, error: `temp file write failed: ${(err as Error).message}` };
  }
  const argv = [
    params.binPath,
    "-a",
    params.accountId,
    "doc",
    "update",
    "--token",
    params.docToken,
    "--mode",
    "overwrite",
    "--file",
    filePath,
  ];
  let result;
  try {
    result = await params.runCommand(argv, { timeoutMs: params.timeoutMs });
  } catch (err) {
    await rm(dir, { recursive: true, force: true }).catch(() => {});
    return { ok: false, error: `feishu doc update spawn failed: ${(err as Error).message}` };
  }
  await rm(dir, { recursive: true, force: true }).catch(() => {});
  if (result.code !== 0) {
    return { ok: false, error: `feishu doc update exit ${result.code} — ${summarizeExecFailure(result)}` };
  }
  return { ok: true };
}

export type SubagentRunFn = (params: {
  sessionKey: string;
  message: string;
  deliver?: boolean;
  lightContext?: boolean;
}) => Promise<{ runId: string }>;

export function createWeeklyReportInteractiveHandler(deps: CreateInteractiveHandlerDeps) {
  const { taskFlow, controllerId, settings, runCommand, subagentRun } = deps;
  const { larkCliBinPath, larkCliAccountId, larkCliTimeoutMs, recipientSessionKey } = settings;

  return async function handler(
    ctx: WeeklyReportInteractiveCtx,
  ): Promise<WeeklyReportInteractiveResult> {
    const { value, formValue } = safeParseEvent(ctx.rawEvent);
    if (!value) {
      return { handled: true, toast: { type: "error", content: "卡片事件无法解析" } };
    }

    const actionVerb = parseEnvelopeAction(value.action);
    const flowId = typeof value.flowId === "string" ? value.flowId : undefined;
    const weekKey = typeof value.weekKey === "string" ? value.weekKey : undefined;
    if (!actionVerb || !flowId || !weekKey) {
      return { handled: true, toast: { type: "error", content: "卡片元数据不完整" } };
    }

    if (!recipientSessionKey) {
      return {
        handled: true,
        toast: { type: "error", content: "插件未配置 recipientSessionKey，无法验证 flow。" },
      };
    }

    const trustResult = validateCardActionTrust({
      taskFlow,
      controllerId,
      bindings: { flowId, weekKey, sessionKey: recipientSessionKey },
    });
    if (!trustResult.ok) {
      const reasonText = trustResult.reason.replace(/_/g, " ");
      return { handled: true, toast: { type: "warning", content: `卡片已失效（${reasonText}）` } };
    }
    const flow = trustResult.flow;
    if (!isWeeklyReportFlowState(flow.stateJson)) {
      return { handled: true, toast: { type: "error", content: "flow 状态损坏，无法读取草稿。" } };
    }
    const state = flow.stateJson;

    if (actionVerb === "supplement") {
      const supplementText = readSupplementText(formValue);
      if (!supplementText) {
        return {
          handled: true,
          toast: { type: "warning", content: "补充内容为空。请在输入框填写后再点击补充。" },
        };
      }

      const revisingTransition = taskFlow.resume({
        flowId: flow.flowId,
        expectedRevision: flow.revision,
        status: "running",
        currentStep: WEEKLY_REPORT_STEPS.revising,
        stateJson: { ...state, supplementSubmittedAt: Date.now() } as never,
      });
      if (!revisingTransition.applied) {
        return {
          handled: true,
          toast: { type: "error", content: "无法将 flow 转入 revising 状态。" },
        };
      }

      await ctx.respond.reply({ text: "📝 已收到补充内容，启动隔离子会话重新整理草稿…" }).catch(() => {});

      if (!subagentRun) {
        return {
          handled: true,
          toast: {
            type: "error",
            content:
              "runtime.subagent 不可用，无法触发 re-draft。请直接在 DM 回复补充内容。",
          },
        };
      }

      const messageText = [
        `承太郎对本周周报（flow=${flow.flowId}，weekKey=${weekKey}）的补充输入：`,
        `"""`,
        supplementText,
        `"""`,
        ``,
        `**这段文字是研究提示，不是要直接抄进草稿的内容。请按下面这个流程处理：**`,
        ``,
        `**1) 解析提示意图**：把上面这段文字分类成下面之一（或几种叠加）。`,
        `   a) **删除/重排指令**（"删除第 N 条" / "第 N 条改为 X" / "把 A 和 B 合并" / "顺序换成 …"）→ 按指示直接对 current_week 数组做结构调整。`,
        `   b) **长期事实 / 角色框定**（"我是 X 项目的 DRI"、"我们做 AI agent"、"团队在 jackery 投放方向"）→ 作为搜索/过滤上下文使用，不要写进 completed 或 intent 里。`,
        `   c) **新增事实指针**（"加上：本周和欢哥对齐了 demo 节奏"、"还要补一条 growx-runtime 的进展"）→ 作为查找事实的 hint。`,
        ``,
        `**2) 重新挖掘事实**（不要凭这段文字本身写 bullet）：基于上面解析出来的提示，在同一回合内重新并行调用：`,
        `   - runtime.subagent.getSessionMessages —— 本 DM 对话过去 7 天，重点查与提示相关的讨论。`,
        `   - fetch_git_activity —— 本周配置仓库中你的提交，重点找提示相关的 commit。`,
        `   - fetch_recent_group_messages —— 本周飞书群消息，重点提取提示提到的人/项目/话题。`,
        ``,
        `**3) 合并而不是替换**：以原草稿作为基线（已经在 flow stateJson 里），按下面规则更新：`,
        `   - 删除/重排指令：按指令重排 current_week；如果某项被删，把它的 next_week 也一并去掉。`,
        `   - 新增事实指针：根据 hint 重新挖掘到的真实素材，补 completed bullet，可能新增 current_week 项目。**不要把承太郎的话本身当成 bullet 内容。**`,
        `   - 长期事实 / 角色框定：吸收为本回合的查询/过滤上下文，让你更精准找到对应项目的 commits/群聊；不要把它本身写进 intent / objective / completed。`,
        `   - 其他原草稿里已经成立的 bullet 全部保留，除非和补充直接冲突。`,
        ``,
        `**4) 草稿硬规则**（与 cron 首轮一致，不允许在 revision 中放松）：`,
        `   - **bullet 文本禁止出现飞书机器 ID**：不允许 \`chat_id\`、\`message_id\`、\`oc_xxx\`、\`om_xxx\`、\`om_x100b...\`。引用群必须用群名（如"技术基建小组"、"claude code 群"、"产研实习生招聘群"、"DM"），引用消息直接引用原话或关键短语，不带 message_id 括号。`,
        `   - **禁止 meta 项目**：current_week 不允许出现以"对上一次周报草稿的反思 / 职责边界澄清 / 群聊素材校正 / 把承太郎对草稿措辞的纠正改写成 bullet"为主题的项目。识别信号：title 含"素材校正"、"职责边界澄清"、"周报口径"，或 intent/objective 谈论"周报应该如何 / 草稿如何修正"——直接砍掉。`,
        `   - **视角必须是承太郎（用户）作为该项目 DRI 的视角**：intent 用"你"指代承太郎本人，描述他为什么做这个项目；objective 是项目本身在产品/业务/技术上要达成什么，不是"让周报反映清楚"这种写作目标；completed 是承太郎本周的实际产出/推进动作。`,
        ``,
        `**5) 调用 submit_weekly_report_draft({ weekKey: "${weekKey}", weekTitle, draftJson, supersedeFlowId: "${flow.flowId}", revisionLabel: "revision 2" })** 提交修订版。该工具会自动投递新卡片；你这一回合到此结束。`,
        ``,
        `**禁止**：把承太郎的原话当 completed bullet；只改 intent/objective 不改事实；不重新调用三个事实源；调用 feishu_ask_user_question；在 bullet 中保留 chat_id/message_id；把"职责边界澄清"之类元工作写成项目。`,
      ].join("\n");

      // Run the re-draft in an isolated sub-session (same shape as cron runs use). Keeps
      // the user's DM clean and prevents the main silver-chariot loop from being entangled in
      // weekly-report meta-conversation. The submit_weekly_report_draft tool, when called from
      // this isolated session, still creates flows owned by recipientSessionKey because the
      // plugin's `withBoundFlow` always binds via `settings.recipientSessionKey` (see index.ts).
      const supplementAgentId =
        /^agent:([^:]+):/u.exec(recipientSessionKey)?.[1] ?? "silver-chariot";
      const isolatedSessionKey =
        `agent:${supplementAgentId}:weekly-report-supplement:${flow.flowId}:${Date.now()}`;
      try {
        await subagentRun({
          sessionKey: isolatedSessionKey,
          message: messageText,
          deliver: false,
        });
      } catch (err) {
        const msg = err instanceof Error ? err.message : String(err);
        return {
          handled: true,
          toast: { type: "error", content: `补充回传失败: ${msg.slice(0, 100)}` },
        };
      }
      return { handled: true, toast: { type: "success", content: "Supplement queued" } };
    }

    // confirm path — do the whole doc-write inline via lark-cli.
    const writingTransition = taskFlow.resume({
      flowId: flow.flowId,
      expectedRevision: flow.revision,
      status: "running",
      currentStep: WEEKLY_REPORT_STEPS.writingDoc,
      stateJson: { ...state, writeStartedAt: Date.now() } as never,
    });
    if (!writingTransition.applied) {
      return {
        handled: true,
        toast: { type: "error", content: "无法将 flow 转入 writing_doc 状态。" },
      };
    }
    const writingRevision = writingTransition.flow.revision;

    await ctx.respond.reply({ text: "✅ 已收到确认，正在写入周报文档…" }).catch(() => {});

    const docToken = state.targetDocToken;
    if (!docToken) {
      taskFlow.fail({
        flowId: flow.flowId,
        expectedRevision: writingRevision,
        stateJson: { ...state, lastError: "targetDocToken missing" } as never,
      });
      return {
        handled: true,
        toast: { type: "error", content: "未配置 targetDocToken，无法写入文档。" },
      };
    }

    if (!larkCliAccountId) {
      taskFlow.fail({
        flowId: flow.flowId,
        expectedRevision: writingRevision,
        stateJson: { ...state, lastError: "larkCliAccountId not configured" } as never,
      });
      return {
        handled: true,
        toast: { type: "error", content: "未配置 larkCliAccountId，无法读取/写入文档。" },
      };
    }
    const fetchRes = await fetchDocMarkdown({
      runCommand,
      binPath: larkCliBinPath,
      accountId: larkCliAccountId,
      docToken,
      timeoutMs: larkCliTimeoutMs,
    });
    if (!fetchRes.ok) {
      taskFlow.fail({
        flowId: flow.flowId,
        expectedRevision: writingRevision,
        stateJson: { ...state, lastError: fetchRes.error } as never,
      });
      return {
        handled: true,
        toast: { type: "error", content: `读取周报文档失败: ${fetchRes.error.slice(0, 100)}` },
      };
    }

    let renderedSection: string;
    try {
      renderedSection = renderReport(state.draft).trimEnd();
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      taskFlow.fail({
        flowId: flow.flowId,
        expectedRevision: writingRevision,
        stateJson: { ...state, lastError: `render failed: ${msg}` } as never,
      });
      return {
        handled: true,
        toast: { type: "error", content: `渲染草稿失败: ${msg.slice(0, 100)}` },
      };
    }

    const splicedBody = spliceWeeklySection({
      existingDoc: fetchRes.markdown,
      weekKey,
      newSectionBody: renderedSection,
    });

    const updateRes = await overwriteDocMarkdown({
      runCommand,
      binPath: larkCliBinPath,
      accountId: larkCliAccountId,
      docToken,
      markdown: splicedBody,
      timeoutMs: larkCliTimeoutMs,
    });
    if (!updateRes.ok) {
      taskFlow.fail({
        flowId: flow.flowId,
        expectedRevision: writingRevision,
        stateJson: { ...state, lastError: updateRes.error } as never,
      });
      return {
        handled: true,
        toast: { type: "error", content: `写入周报文档失败: ${updateRes.error.slice(0, 100)}` },
      };
    }

    taskFlow.finish({
      flowId: flow.flowId,
      expectedRevision: writingRevision,
      stateJson: { ...state, writeStartedAt: state.writeStartedAt ?? Date.now(), writtenAt: Date.now() } as never,
    });

    await ctx.respond.reply({ text: `✅ 周报已写入文档（${state.weekTitle}）。` }).catch(() => {});

    return { handled: true, toast: { type: "success", content: "Report written" } };
  };
}
